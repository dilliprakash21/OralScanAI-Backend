import { ReactNode } from "react";

interface MobileLayoutProps {
  children: ReactNode;
  className?: string;
  noPadding?: boolean;
}

export function MobileLayout({ children, className = "", noPadding = false }: MobileLayoutProps) {
  return (
    <div className={`mobile-screen ${noPadding ? "" : "px-4"} ${className}`}>
      {children}
    </div>
  );
}
