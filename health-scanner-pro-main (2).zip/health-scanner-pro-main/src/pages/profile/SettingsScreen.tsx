import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { ActionButton } from "@/components/ui/ActionButton";
import { BottomNav } from "@/components/layout/BottomNav";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  ChevronRight, Bell, Moon, Sun, Globe, Shield, Info, LogOut, Trash2, Lock
} from "lucide-react";
import { toast } from "sonner";

export default function SettingsScreen() {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const [darkMode, setDarkMode] = useState(document.documentElement.classList.contains("dark"));
  const [notifications, setNotifications] = useState(true);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletePassword, setDeletePassword] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(false);

  const toggleDark = () => {
    document.documentElement.classList.toggle("dark");
    setDarkMode(!darkMode);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
    toast.success("Signed out successfully");
  };

  const handleDeleteAccount = async () => {
    if (!deletePassword) { toast.error("Please enter your password"); return; }
    setDeleteLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: user!.email!, password: deletePassword });
      if (error) { toast.error("Incorrect password"); setDeleteLoading(false); return; }
      toast.error("Account deletion requires admin approval. Please contact support.");
      setShowDeleteModal(false);
    } catch {
      toast.error("Failed to verify identity");
    } finally {
      setDeleteLoading(false);
    }
  };

  const sections = [
    {
      title: "App Preferences",
      items: [
        {
          icon: darkMode ? Moon : Sun,
          label: darkMode ? "Dark Mode" : "Light Mode",
          action: toggleDark,
          rightEl: (
            <div onClick={toggleDark} className={`w-12 h-6 rounded-full transition-all cursor-pointer ${darkMode ? "bg-primary" : "bg-muted"}`}>
              <div className={`w-5 h-5 rounded-full bg-white shadow transition-all mt-0.5 ${darkMode ? "ml-6.5" : "ml-0.5"}`} />
            </div>
          ),
        },
        {
          icon: Bell,
          label: "Notifications",
          action: () => setNotifications(!notifications),
          rightEl: (
            <div onClick={() => setNotifications(!notifications)} className={`w-12 h-6 rounded-full transition-all cursor-pointer ${notifications ? "bg-primary" : "bg-muted"}`}>
              <div className={`w-5 h-5 rounded-full bg-white shadow transition-all mt-0.5 ${notifications ? "ml-6.5" : "ml-0.5"}`} />
            </div>
          ),
        },
      ],
    },
    {
      title: "Data & Privacy",
      items: [
        { icon: Globe, label: "Sync Settings", action: () => navigate("/settings/sync"), rightEl: <ChevronRight className="w-5 h-5 text-muted-foreground" /> },
        { icon: Shield, label: "Disclaimer", action: () => navigate("/disclaimer"), rightEl: <ChevronRight className="w-5 h-5 text-muted-foreground" /> },
      ],
    },
    {
      title: "Information",
      items: [
        { icon: Info, label: "About Clinical Indices", action: () => navigate("/about-indices"), rightEl: <ChevronRight className="w-5 h-5 text-muted-foreground" /> },
        { icon: Info, label: "Help & Support", action: () => navigate("/help"), rightEl: <ChevronRight className="w-5 h-5 text-muted-foreground" /> },
      ],
    },
    {
      title: "Account",
      items: [
        {
          icon: LogOut,
          label: "Sign Out",
          action: handleSignOut,
          danger: true,
          rightEl: <ChevronRight className="w-5 h-5 text-destructive/60" />,
        },
        {
          icon: Trash2,
          label: "Delete Account",
          action: () => setShowDeleteModal(true),
          danger: true,
          rightEl: <ChevronRight className="w-5 h-5 text-destructive/60" />,
        },
      ],
    },
  ];

  return (
    <MobileLayout className="pb-20">
      <ScreenHeader title="Settings" />

      <div className="px-4 pt-4 space-y-5 animate-fade-in">
        {/* User Info */}
        <div className="bg-card rounded-2xl border border-border p-4 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-lg">
            {user?.email?.[0].toUpperCase() || "U"}
          </div>
          <div>
            <p className="font-semibold text-foreground">{user?.email}</p>
            <p className="text-xs text-muted-foreground">Signed in</p>
          </div>
        </div>

        {sections.map((section) => (
          <div key={section.title} className="space-y-1">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-1">{section.title}</p>
            <div className="bg-card rounded-2xl border border-border overflow-hidden">
              {section.items.map(({ icon: Icon, label, action, danger, rightEl }, i) => (
                <button
                  key={label}
                  onClick={action}
                  className={`w-full flex items-center gap-4 p-4 text-left transition-colors hover:bg-muted/50 ${
                    i < section.items.length - 1 ? "border-b border-border" : ""
                  }`}
                >
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${danger ? "bg-destructive/10" : "bg-muted"}`}>
                    <Icon className={`w-5 h-5 ${danger ? "text-destructive" : "text-foreground"}`} />
                  </div>
                  <span className={`flex-1 font-medium text-sm ${danger ? "text-destructive" : "text-foreground"}`}>{label}</span>
                  {rightEl}
                </button>
              ))}
            </div>
          </div>
        ))}

        <p className="text-center text-xs text-muted-foreground pb-2">OralScan AI v1.0.0</p>
      </div>

      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={() => setShowDeleteModal(false)}>
          <div className="w-full max-w-md mx-auto bg-card rounded-t-3xl p-6 space-y-5" onClick={(e) => e.stopPropagation()}>
            <div className="w-10 h-1 bg-muted rounded-full mx-auto" />
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-destructive/10 flex items-center justify-center">
                <Lock className="w-6 h-6 text-destructive" />
              </div>
              <div>
                <h3 className="font-bold text-foreground text-lg">Delete Account</h3>
                <p className="text-sm text-muted-foreground">Confirm your password to proceed</p>
              </div>
            </div>
            <input
              type="password"
              placeholder="Enter your password"
              value={deletePassword}
              onChange={(e) => setDeletePassword(e.target.value)}
              className="w-full h-14 px-4 rounded-xl border-2 border-border focus:border-destructive bg-background text-foreground outline-none"
              autoFocus
            />
            <div className="grid grid-cols-2 gap-3">
              <ActionButton variant="outline" onClick={() => setShowDeleteModal(false)}>Cancel</ActionButton>
              <ActionButton variant="destructive" onClick={handleDeleteAccount} loading={deleteLoading}>Confirm</ActionButton>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </MobileLayout>
  );
}
