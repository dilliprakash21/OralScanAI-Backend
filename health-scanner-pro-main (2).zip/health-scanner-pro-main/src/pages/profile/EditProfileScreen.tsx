import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { ActionButton } from "@/components/ui/ActionButton";
import { User, Mail, Phone, MapPin, Stethoscope, Building, Camera } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

function validateIndianPhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, "").replace(/^\+91/, "");
  if (digits.length === 0) return "Phone number is required";
  if (digits.length !== 10) return "Phone number must be exactly 10 digits";
  if (!/^[6-9]/.test(digits)) return "Enter a valid Indian mobile number";
  return null;
}

export default function EditProfileScreen() {
  const navigate = useNavigate();
  const { profile, user, refreshProfile } = useAuth();
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState({
    name: "", phone: "", clinic: "", hospital: "", location: "", license_no: ""
  });
  const [phoneError, setPhoneError] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      const rawPhone = profile.phone?.replace(/^\+91/, "") || "";
      setForm({
        name: profile.name || "",
        phone: rawPhone,
        clinic: profile.clinic || "",
        hospital: profile.hospital || "",
        location: profile.location || "",
        license_no: profile.license_no || "",
      });
      setAvatarUrl(profile.avatar_url || null);
    }
  }, [profile]);

  const handlePhoneChange = (value: string) => {
    const digits = value.replace(/\D/g, "").slice(0, 10);
    setForm(f => ({ ...f, phone: digits }));
    setPhoneError(digits.length > 0 ? validateIndianPhone(digits) : null);
  };

  const handleAvatarUpload = async (file: File) => {
    if (!user) return;
    if (!file.type.startsWith("image/")) { toast.error("Please select an image"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("Image must be under 5MB"); return; }

    setUploadingAvatar(true);
    try {
      const ext = file.name.split('.').pop();
      const filePath = `${user.id}/avatar.${ext}`;
      
      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(filePath, file, { upsert: true });
      
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("avatars")
        .getPublicUrl(filePath);

      // Add cache-busting
      const urlWithCache = `${publicUrl}?t=${Date.now()}`;
      setAvatarUrl(urlWithCache);

      // Update profile with avatar URL
      await supabase.from("profiles").update({ avatar_url: urlWithCache }).eq("user_id", user.id);
      toast.success("Profile photo updated!");
    } catch (err) {
      console.error(err);
      toast.error("Failed to upload photo");
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSave = async () => {
    const phoneErr = validateIndianPhone(form.phone);
    if (phoneErr) { setPhoneError(phoneErr); return; }
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase.from("profiles").upsert({
        user_id: user.id,
        name: form.name,
        email: profile?.email || user.email,
        phone: `+91${form.phone}`,
        clinic: form.clinic,
        hospital: form.hospital,
        location: form.location,
        license_no: form.license_no,
        avatar_url: avatarUrl,
      }, { onConflict: "user_id" });

      if (error) { toast.error(error.message); return; }
      await refreshProfile();
      toast.success("Profile updated successfully");
      navigate("/profile");
    } catch {
      toast.error("Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  const fields = [
    { icon: User, key: "name", label: "Full Name", placeholder: "Your full name", type: "text" },
    { icon: Stethoscope, key: "license_no", label: "License / Registration No.", placeholder: "DCI-XXXX-XXXXX", type: "text" },
    { icon: Building, key: "clinic", label: "Clinic Name", placeholder: "Clinic name", type: "text" },
    { icon: Building, key: "hospital", label: "Hospital / Organization", placeholder: "Hospital name", type: "text" },
    { icon: MapPin, key: "location", label: "Location", placeholder: "City, State", type: "text" },
  ];

  return (
    <MobileLayout noPadding>
      <ScreenHeader title="Edit Profile" />
      <div className="flex-1 px-4 py-6 overflow-auto">
        {/* Avatar Upload */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden border-4 border-primary/20">
              {avatarUrl ? (
                <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User className="w-10 h-10 text-primary" />
              )}
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadingAvatar}
              className="absolute -bottom-1 -right-1 w-8 h-8 bg-primary rounded-full flex items-center justify-center border-2 border-background shadow-md"
            >
              <Camera className="w-4 h-4 text-primary-foreground" />
            </button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleAvatarUpload(e.target.files[0])}
          />
          {uploadingAvatar && <p className="text-xs text-primary mt-2">Uploading...</p>}
          <p className="text-xs text-muted-foreground mt-1">Tap camera icon to change photo</p>
        </div>

        <div className="space-y-4">
          {/* Email (read-only) */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input type="email" value={profile?.email || user?.email || ""} disabled
                className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border bg-muted text-muted-foreground outline-none" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">Contact support to change your email</p>
          </div>

          {/* Phone */}
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Phone</label>
            <div className="flex">
              <div className="flex items-center justify-center px-3 h-14 bg-muted border-2 border-r-0 border-border rounded-l-xl text-sm font-semibold text-foreground">+91</div>
              <div className="relative flex-1">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input type="tel" inputMode="numeric" placeholder="10-digit mobile number"
                  value={form.phone} onChange={(e) => handlePhoneChange(e.target.value)} maxLength={10}
                  className={`w-full h-14 pl-10 pr-4 rounded-r-xl border-2 ${phoneError ? "border-destructive" : "border-border focus:border-primary"} bg-card text-foreground outline-none`} />
              </div>
            </div>
            {phoneError && <p className="text-xs text-destructive mt-1">{phoneError}</p>}
          </div>

          {/* Other fields */}
          {fields.map(({ icon: Icon, key, label, placeholder, type }) => (
            <div key={key}>
              <label className="text-sm font-medium text-foreground mb-1 block">{label}</label>
              <div className="relative">
                <Icon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input type={type} placeholder={placeholder} value={form[key as keyof typeof form]}
                  onChange={(e) => setForm(f => ({ ...f, [key]: e.target.value }))}
                  className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 space-y-3">
          <ActionButton loading={saving} onClick={handleSave}>Save Changes</ActionButton>
          <ActionButton variant="outline" onClick={() => navigate("/profile")}>Cancel</ActionButton>
        </div>
      </div>
    </MobileLayout>
  );
}
