import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";
import { Activity, Users, TrendingUp, AlertTriangle, Loader2 } from "lucide-react";
import { format, subDays } from "date-fns";

interface Stats {
  total: number;
  low: number;
  medium: number;
  high: number;
  thisWeek: number;
  avgConfidence: number;
}

export default function StatisticsScreen() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats>({ total: 0, low: 0, medium: 0, high: 0, thisWeek: 0, avgConfidence: 0 });
  const [dailyData, setDailyData] = useState<Array<{ date: string; count: number }>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchStats();
  }, [user]);

  const fetchStats = async () => {
    const { data, error } = await supabase
      .from("screenings")
      .select("risk_level, ai_confidence, created_at")
      .eq("user_id", user!.id);

    if (error || !data) { setLoading(false); return; }

    const now = new Date();
    const weekAgo = subDays(now, 7);

    const s: Stats = {
      total: data.length,
      low: data.filter((r) => r.risk_level === "low").length,
      medium: data.filter((r) => r.risk_level === "medium").length,
      high: data.filter((r) => r.risk_level === "high").length,
      thisWeek: data.filter((r) => r.created_at && new Date(r.created_at) >= weekAgo).length,
      avgConfidence: data.length ? Math.round(data.reduce((s, r) => s + (r.ai_confidence || 0), 0) / data.length) : 0,
    };
    setStats(s);

    // Build last 7 days chart
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = subDays(now, 6 - i);
      const dateStr = format(d, "yyyy-MM-dd");
      return {
        date: format(d, "dd MMM"),
        count: data.filter((r) => r.created_at?.startsWith(dateStr)).length,
      };
    });
    setDailyData(days);
    setLoading(false);
  };

  const pieData = [
    { name: "Low Risk", value: stats.low, color: "hsl(var(--risk-low))" },
    { name: "Medium Risk", value: stats.medium, color: "hsl(var(--risk-medium))" },
    { name: "High Risk", value: stats.high, color: "hsl(var(--risk-high))" },
  ].filter((d) => d.value > 0);

  const statCards = [
    { label: "Total Screenings", value: stats.total, icon: Users, color: "text-primary" },
    { label: "This Week", value: stats.thisWeek, icon: TrendingUp, color: "text-success" },
    { label: "High Risk", value: stats.high, icon: AlertTriangle, color: "text-destructive" },
    { label: "Avg Confidence", value: `${stats.avgConfidence}%`, icon: Activity, color: "text-info" },
  ];

  return (
    <MobileLayout className="pb-20">
      <ScreenHeader title="Statistics" />

      {loading ? (
        <div className="flex items-center justify-center flex-1 py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="px-4 pt-4 space-y-5 animate-fade-in">
          {/* Stat Cards */}
          <div className="grid grid-cols-2 gap-3">
            {statCards.map(({ label, value, icon: Icon, color }) => (
              <div key={label} className="bg-card rounded-2xl border border-border p-4">
                <div className={`${color} mb-2`}><Icon className="w-5 h-5" /></div>
                <p className="text-2xl font-bold text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
              </div>
            ))}
          </div>

          {/* Daily Chart */}
          <div className="bg-card rounded-2xl border border-border p-4">
            <p className="text-sm font-semibold text-foreground mb-4">Screenings — Last 7 Days</p>
            {dailyData.some((d) => d.count > 0) ? (
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={dailyData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
                    labelStyle={{ color: "hsl(var(--foreground))" }}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} name="Screenings" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">
                No screenings in the last 7 days
              </div>
            )}
          </div>

          {/* Risk Distribution */}
          {stats.total > 0 && (
            <div className="bg-card rounded-2xl border border-border p-4">
              <p className="text-sm font-semibold text-foreground mb-4">Risk Distribution</p>
              <div className="flex items-center gap-4">
                <ResponsiveContainer width="50%" height={150}>
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={3} dataKey="value">
                      {pieData.map((entry, index) => (
                        <Cell key={index} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-2">
                  {[
                    { label: "Low", value: stats.low, color: "bg-risk-low" },
                    { label: "Medium", value: stats.medium, color: "bg-risk-medium" },
                    { label: "High", value: stats.high, color: "bg-risk-high" },
                  ].map(({ label, value, color }) => (
                    <div key={label} className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-sm ${color}`} />
                      <span className="text-sm text-foreground flex-1">{label}</span>
                      <span className="text-sm font-bold text-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* More Views */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => navigate("/statistics/location")}
              className="bg-card rounded-2xl border border-border p-4 text-left hover:border-primary/40 transition-all"
            >
              <p className="text-2xl mb-1">🗺️</p>
              <p className="font-semibold text-foreground text-sm">Location Analysis</p>
              <p className="text-xs text-muted-foreground mt-0.5">By area & village</p>
            </button>
            <button
              onClick={() => navigate("/statistics/camps")}
              className="bg-card rounded-2xl border border-border p-4 text-left hover:border-primary/40 transition-all"
            >
              <p className="text-2xl mb-1">🏕️</p>
              <p className="font-semibold text-foreground text-sm">Camp Summaries</p>
              <p className="text-xs text-muted-foreground mt-0.5">Camp-wise reports</p>
            </button>
          </div>
        </div>
      )}
      <BottomNav />
    </MobileLayout>
  );
}
