import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Tent, Loader2 } from "lucide-react";
import { format } from "date-fns";

interface CampSummary {
  date: string;
  location: string;
  total: number;
  high: number;
  medium: number;
  low: number;
}

export default function CampSummariesScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [camps, setCamps] = useState<CampSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("screenings")
      .select("created_at, location, risk_level, mode")
      .eq("user_id", user.id)
      .eq("mode", "camp")
      .then(({ data: rows }) => {
        // Group by date + location
        const map: Record<string, CampSummary> = {};
        (rows || []).forEach((r) => {
          const dateStr = r.created_at ? format(new Date(r.created_at), "yyyy-MM-dd") : "unknown";
          const key = `${dateStr}__${r.location || "Unknown"}`;
          if (!map[key]) map[key] = {
            date: r.created_at ? format(new Date(r.created_at), "dd MMM yyyy") : "—",
            location: r.location || "Unknown Location",
            total: 0, high: 0, medium: 0, low: 0,
          };
          map[key].total++;
          if (r.risk_level === "high") map[key].high++;
          else if (r.risk_level === "medium") map[key].medium++;
          else map[key].low++;
        });
        setCamps(Object.values(map).sort((a, b) => b.date.localeCompare(a.date)));
        setLoading(false);
      });
  }, [user]);

  return (
    <MobileLayout className="pb-6">
      <ScreenHeader title="Camp Summaries" onBack={() => navigate("/statistics")} />

      <div className="px-4 pt-4 space-y-4 animate-fade-in">
        <p className="text-sm text-muted-foreground">Screenings conducted in camp mode</p>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : camps.length === 0 ? (
          <div className="text-center py-16">
            <Tent className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
            <p className="font-semibold text-foreground">No camp data</p>
            <p className="text-sm text-muted-foreground mt-1">Start a screening in Camp Mode to see summaries here.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {camps.map((camp, i) => (
              <div key={i} className="bg-card rounded-2xl border border-border p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <Tent className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{camp.location}</p>
                      <p className="text-xs text-muted-foreground">{camp.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-foreground">{camp.total}</p>
                    <p className="text-xs text-muted-foreground">patients</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {[
                    { label: `${camp.low} Low`, color: "bg-success/10 text-success" },
                    { label: `${camp.medium} Med`, color: "bg-warning/10 text-warning" },
                    { label: `${camp.high} High`, color: "bg-destructive/10 text-destructive" },
                  ].map(({ label, color }) => (
                    <span key={label} className={`text-xs font-semibold px-2 py-1 rounded-lg ${color}`}>{label}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
