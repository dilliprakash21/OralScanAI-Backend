import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { MapPin, Loader2 } from "lucide-react";

interface LocationStat {
  location: string;
  total: number;
  high: number;
  medium: number;
  low: number;
}

export default function LocationHeatmapScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [data, setData] = useState<LocationStat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("screenings")
      .select("location, risk_level")
      .eq("user_id", user.id)
      .then(({ data: rows }) => {
        const map: Record<string, LocationStat> = {};
        (rows || []).forEach((r) => {
          const loc = r.location || "Unknown";
          if (!map[loc]) map[loc] = { location: loc, total: 0, high: 0, medium: 0, low: 0 };
          map[loc].total++;
          if (r.risk_level === "high") map[loc].high++;
          else if (r.risk_level === "medium") map[loc].medium++;
          else map[loc].low++;
        });
        setData(Object.values(map).sort((a, b) => b.total - a.total));
        setLoading(false);
      });
  }, [user]);

  const maxTotal = Math.max(...data.map((d) => d.total), 1);

  return (
    <MobileLayout className="pb-6">
      <ScreenHeader title="Location Analysis" onBack={() => navigate("/statistics")} />

      <div className="px-4 pt-4 space-y-4 animate-fade-in">
        <p className="text-sm text-muted-foreground">Screening activity by location</p>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : data.length === 0 ? (
          <div className="text-center py-16">
            <MapPin className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
            <p className="font-semibold text-foreground">No location data</p>
            <p className="text-sm text-muted-foreground mt-1">Location data will appear once screenings include a location.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {data.map((loc) => (
              <div key={loc.location} className="bg-card rounded-2xl border border-border p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-primary" />
                    <p className="font-semibold text-foreground text-sm">{loc.location}</p>
                  </div>
                  <span className="text-sm font-bold text-foreground">{loc.total} screenings</span>
                </div>
                {/* Bar */}
                <div className="h-3 bg-muted rounded-full overflow-hidden mb-2">
                  <div
                    className="h-full bg-primary rounded-full transition-all"
                    style={{ width: `${(loc.total / maxTotal) * 100}%` }}
                  />
                </div>
                {/* Risk breakdown */}
                <div className="flex gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-sm bg-success inline-block" />
                    Low: {loc.low}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-sm bg-warning inline-block" />
                    Med: {loc.medium}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-sm bg-destructive inline-block" />
                    High: {loc.high}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
