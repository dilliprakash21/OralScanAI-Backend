import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { ActionButton } from "@/components/ui/ActionButton";
import { ProgressSteps } from "@/components/layout/ProgressSteps";
import { useScreening } from "@/contexts/ScreeningContext";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";

export default function SaveRecordScreen() {
  const navigate = useNavigate();
  const { data, resetData } = useScreening();
  const { user } = useAuth();
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);

  const handleSave = async () => {
    if (!user) { toast.error("Please log in to save records"); return; }
    if (!data.patientId || !data.patientName) { toast.error("Missing patient information"); navigate("/screening/patient-details"); return; }

    setLoading(true);
    try {
      const { data: record, error } = await supabase.from("screenings").insert({
        user_id: user.id,
        patient_id: data.patientId!,
        patient_name: data.patientName,
        age: data.age,
        dob: data.dob,
        gender: data.gender,
        phone: data.phone,
        location: data.location,
        consent_given: data.consentGiven ?? false,
        image_url: data.imageUrl,
        heatmap_url: data.heatmapUrl,
        risk_level: data.riskLevel,
        ai_confidence: data.aiConfidence,
        plaque_index: data.plaqueIndex,
        gingival_index: data.gingivalIndex,
        overridden: data.overridden ?? false,
        override_reason: data.overrideReason,
        referral_clinic: data.referralClinic,
        notes: notes.trim() || null,
        mode: data.mode || "screening",
      }).select().single();

      if (error) throw error;
      setSaved(true);
      setSavedId(record.id);
      toast.success("Record saved successfully!");
    } catch (err) {
      console.error(err);
      toast.error("Failed to save record. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleFinish = () => {
    resetData();
    navigate("/dashboard");
  };

  if (saved) {
    return (
      <MobileLayout className="items-center justify-center">
        <div className="px-6 flex flex-col items-center gap-6 text-center animate-fade-in">
          <div className="w-24 h-24 rounded-full bg-success/15 flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-success" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground">Record Saved!</h2>
            <p className="text-muted-foreground mt-2">
              Screening for <span className="font-semibold text-foreground">{data.patientName}</span> has been saved.
            </p>
            {savedId && <p className="text-xs text-muted-foreground mt-1">Record ID: {savedId.slice(0, 8).toUpperCase()}</p>}
          </div>
          <div className="w-full space-y-3">
            <ActionButton onClick={() => navigate(`/records/${savedId}`)}>
              View Record
            </ActionButton>
            <ActionButton variant="outline" onClick={handleFinish}>
              Back to Dashboard
            </ActionButton>
          </div>
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout className="pb-6">
      <ScreenHeader title="Save Record" onBack={() => navigate("/screening/referral")} />
      <ProgressSteps currentStep={8} totalSteps={8} />

      <div className="px-4 pt-4 space-y-4 animate-fade-in">
        {/* Summary */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-bold text-foreground">{data.patientName || "—"}</p>
              <p className="text-sm text-muted-foreground">{data.patientId}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            {[
              { label: "Age / Gender", value: `${data.age || "—"} / ${data.gender || "—"}` },
              { label: "Risk Level", value: data.riskLevel?.toUpperCase() || "—" },
              { label: "AI Confidence", value: `${data.aiConfidence || 0}%` },
              { label: "Referral", value: data.referralClinic || "None" },
            ].map(({ label, value }) => (
              <div key={label}>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="font-medium text-foreground capitalize truncate">{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Notes */}
        <div className="space-y-2">
          <label className="text-sm font-semibold text-foreground">Clinical Notes (Optional)</label>
          <textarea
            placeholder="Add clinical observations, follow-up instructions, or other notes..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            maxLength={1000}
            className="w-full px-4 py-3 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none text-sm resize-none"
          />
          <p className="text-xs text-muted-foreground text-right">{notes.length}/1000</p>
        </div>

        <ActionButton onClick={handleSave} loading={loading}>
          {loading ? "Saving..." : "Save Screening Record"}
        </ActionButton>
      </div>
    </MobileLayout>
  );
}
