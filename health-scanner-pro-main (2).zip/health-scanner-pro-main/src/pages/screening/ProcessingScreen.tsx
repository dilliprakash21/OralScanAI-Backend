import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { useScreening } from "@/contexts/ScreeningContext";

const stages = [
  { label: "Preprocessing image...", duration: 1200 },
  { label: "Detecting lesion regions...", duration: 1500 },
  { label: "Generating heatmap...", duration: 1300 },
  { label: "Calculating risk indices...", duration: 1000 },
  { label: "Finalising results...", duration: 800 },
];

function simulateAIResult(imageUrl: string) {
  // Deterministic simulation based on image data length
  const seed = (imageUrl?.length || 100) % 3;
  const risks: Array<"low" | "medium" | "high"> = ["low", "medium", "high"];
  const riskLevel = risks[seed];
  return {
    riskLevel,
    aiConfidence: 75 + Math.floor(Math.random() * 20),
    plaqueIndex: parseFloat((1 + Math.random() * 2).toFixed(1)),
    gingivalIndex: parseFloat((0.5 + Math.random() * 1.5).toFixed(1)),
  };
}

export default function ProcessingScreen() {
  const navigate = useNavigate();
  const { data, updateData } = useScreening();
  const [stageIndex, setStageIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!data.imageUrl) { navigate("/screening/capture"); return; }

    let elapsed = 0;
    const totalDuration = stages.reduce((s, st) => s + st.duration, 0);
    let currentStage = 0;

    const interval = setInterval(() => {
      elapsed += 80;
      setProgress(Math.min((elapsed / totalDuration) * 100, 99));

      let stageCumulative = 0;
      for (let i = 0; i < stages.length; i++) {
        stageCumulative += stages[i].duration;
        if (elapsed < stageCumulative) { setStageIndex(i); break; }
        currentStage = i;
      }
    }, 80);

    const timer = setTimeout(() => {
      clearInterval(interval);
      const result = simulateAIResult(data.imageUrl!);
      updateData(result);
      setProgress(100);
      setTimeout(() => navigate("/screening/heatmap"), 400);
    }, totalDuration);

    return () => { clearInterval(interval); clearTimeout(timer); };
  }, []);

  return (
    <MobileLayout className="items-center justify-center bg-primary">
      <div className="flex flex-col items-center gap-8 px-8 text-center">
        {/* Animated brain/scan */}
        <div className="relative w-32 h-32">
          <div className="absolute inset-0 rounded-full bg-primary-foreground/20 animate-pulse-ring" />
          <div className="absolute inset-4 rounded-full bg-primary-foreground/20 animate-pulse-ring" style={{ animationDelay: "0.5s" }} />
          <div className="absolute inset-0 rounded-full bg-primary-foreground/10 flex items-center justify-center">
            <svg className="w-14 h-14 text-primary-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5V5a1 1 0 0 0 1 1 2 2 0 0 1 0 4 1 1 0 0 0-1 1v.5A2.5 2.5 0 0 1 9.5 14h-1A2.5 2.5 0 0 1 6 11.5V11a1 1 0 0 0-1-1 2 2 0 0 1 0-4 1 1 0 0 0 1-1v-.5A2.5 2.5 0 0 1 8.5 2h1z" />
              <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v.5" />
              <path d="M14.5 14A2.5 2.5 0 0 0 12 11.5V11" />
              <path d="M15 7h1.5A2.5 2.5 0 0 1 19 9.5v1a2.5 2.5 0 0 1-2.5 2.5H15" />
            </svg>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-primary-foreground">Analysing</h2>
          <p className="text-primary-foreground/70 mt-1 text-sm">AI is processing the oral cavity image</p>
        </div>

        {/* Progress bar */}
        <div className="w-full max-w-xs space-y-2">
          <div className="h-2 bg-primary-foreground/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary-foreground rounded-full transition-all duration-200 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-primary-foreground/60">
            <span>{stages[Math.min(stageIndex, stages.length - 1)]?.label}</span>
            <span>{Math.round(progress)}%</span>
          </div>
        </div>

        <p className="text-xs text-primary-foreground/50 max-w-xs">
          This AI analysis is a decision-support tool and does not replace clinical judgment.
        </p>
      </div>
    </MobileLayout>
  );
}
