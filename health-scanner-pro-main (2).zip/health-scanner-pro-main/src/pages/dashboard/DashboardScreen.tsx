import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { BottomNav } from "@/components/layout/BottomNav";
import { Plus, Tent, FolderOpen, BarChart3, Bell, X } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { RiskBadge } from "@/components/ui/RiskBadge";
import oralScanLogo from "@/assets/oralscan-logo.png";
import { formatDistanceToNow } from "date-fns";

interface RecentScreening {
  id: string;
  patient_id: string;
  risk_level: string | null;
  created_at: string | null;
}

export default function DashboardScreen() {
  const navigate = useNavigate();
  const { profile, user } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [recentScreenings, setRecentScreenings] = useState<RecentScreening[]>([]);
  const [stats, setStats] = useState({ today: 0, week: 0, lowRiskPercent: 0 });

  useEffect(() => {
    if (!user) return;
    // Fetch notifications
    supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20)
      .then(({ data }) => setNotifications(data || []));

    // Fetch recent screenings
    supabase
      .from("screenings")
      .select("id,patient_id,risk_level,created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(5)
      .then(({ data }) => setRecentScreenings(data || []));

    // Fetch stats
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    const weekStart = new Date(now.getTime() - 7 * 86400000).toISOString();

    supabase
      .from("screenings")
      .select("id,risk_level,created_at")
      .eq("user_id", user.id)
      .gte("created_at", weekStart)
      .then(({ data }) => {
        const weekData = data || [];
        const todayData = weekData.filter((s) => s.created_at && s.created_at >= todayStart);
        const lowRisk = weekData.filter((s) => s.risk_level === "low").length;
        setStats({
          today: todayData.length,
          week: weekData.length,
          lowRiskPercent: weekData.length > 0 ? Math.round((lowRisk / weekData.length) * 100) : 0,
        });
      });
  }, [user]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllRead = async () => {
    if (!user) return;
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const menuItems = [
    { icon: Plus, label: "New Screening", description: "Start a new patient assessment", color: "bg-primary", textColor: "text-primary-foreground", action: () => navigate("/screening/consent") },
    { icon: Tent, label: "Camp Mode", description: "Start a community screening camp", color: "bg-success", textColor: "text-success-foreground", action: () => navigate("/camp-mode") },
    { icon: FolderOpen, label: "Records", description: "View past screenings", color: "bg-info", textColor: "text-info-foreground", action: () => navigate("/records") },
    { icon: BarChart3, label: "Statistics", description: "View screening analytics", color: "bg-warning", textColor: "text-warning-foreground", action: () => navigate("/statistics") },
  ];

  const displayName = profile?.name || user?.user_metadata?.name || "Doctor";

  return (
    <MobileLayout noPadding className="pb-20">
      {/* Header */}
      <div className="bg-primary px-4 pt-6 pb-8 safe-top">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-foreground rounded-xl overflow-hidden">
              <img src={oralScanLogo} alt="Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <p className="text-primary-foreground font-semibold text-lg">OralScan AI</p>
              <p className="text-primary-foreground/80 text-xs">Welcome back, {displayName}</p>
            </div>
          </div>
          <button onClick={() => setShowNotifications(true)} className="relative w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center">
            <Bell className="w-5 h-5 text-primary-foreground" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive rounded-full text-white text-xs flex items-center justify-center">{unreadCount}</span>
            )}
          </button>
        </div>

        {/* Stats Bar */}
        <div className="bg-primary-foreground/15 backdrop-blur-sm rounded-2xl p-4 grid grid-cols-3 gap-3">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary-foreground">{stats.today}</p>
            <p className="text-xs text-primary-foreground/70">Today</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary-foreground">{stats.week}</p>
            <p className="text-xs text-primary-foreground/70">This Week</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-success">{stats.lowRiskPercent}%</p>
            <p className="text-xs text-primary-foreground/70">Low Risk</p>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div className="px-4 -mt-4">
        <div className="grid grid-cols-2 gap-3">
          {menuItems.map((item, index) => (
            <button key={item.label} onClick={item.action}
              className="card-dashboard flex flex-col items-start gap-3 animate-fade-in"
              style={{ animationDelay: `${index * 80}ms` }}>
              <div className={`w-12 h-12 ${item.color} rounded-2xl flex items-center justify-center`}>
                <item.icon className={`w-6 h-6 ${item.textColor}`} />
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Screenings */}
      {recentScreenings.length > 0 && (
        <div className="px-4 mt-6">
          <h3 className="text-sm font-bold text-primary uppercase tracking-wider mb-3">Recent Screenings</h3>
          <div className="space-y-2">
            {recentScreenings.map((s) => (
              <button
                key={s.id}
                onClick={() => navigate(`/records/${s.id}`)}
                className="w-full flex items-center justify-between p-4 bg-card rounded-xl border border-border hover:border-primary/40 transition-all"
              >
                <div>
                  <p className="font-semibold text-foreground text-sm">{s.patient_id}</p>
                  <p className="text-xs text-muted-foreground">
                    {s.created_at ? formatDistanceToNow(new Date(s.created_at), { addSuffix: true }) : ""}
                  </p>
                </div>
                {s.risk_level && (
                  <RiskBadge level={s.risk_level as "low" | "medium" | "high"} size="small" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Notifications Panel */}
      {showNotifications && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={() => setShowNotifications(false)}>
          <div className="bg-card w-full max-w-md mx-auto rounded-t-3xl p-4 max-h-[60vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-foreground">Notifications</h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && <button onClick={markAllRead} className="text-xs text-primary font-medium">Mark all read</button>}
                <button onClick={() => setShowNotifications(false)}><X className="w-5 h-5 text-muted-foreground" /></button>
              </div>
            </div>
            <div className="overflow-auto flex-1">
              {notifications.length === 0 ? (
                <div className="text-center py-8">
                  <Bell className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-muted-foreground text-sm">No notifications yet</p>
                </div>
              ) : (
                notifications.map((n) => (
                  <div key={n.id} className={`p-3 rounded-xl mb-2 ${n.read ? "bg-muted/40" : "bg-accent"}`}>
                    <p className="text-sm text-foreground">{n.text}</p>
                    <p className="text-xs text-muted-foreground mt-1">{new Date(n.created_at).toLocaleString()}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </MobileLayout>
  );
}
