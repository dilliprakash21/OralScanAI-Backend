import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { ActionButton } from "@/components/ui/ActionButton";
import { RiskBadge } from "@/components/ui/RiskBadge";
import { BottomNav } from "@/components/layout/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Search, Download, Lock, Filter, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

type FilterPeriod = "all" | "today" | "week" | "month";

interface Screening {
  id: string;
  patient_name: string | null;
  patient_id: string;
  risk_level: string | null;
  ai_confidence: number | null;
  created_at: string | null;
  gender: string | null;
  age: number | null;
  location: string | null;
}

export default function RecordsListScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [records, setRecords] = useState<Screening[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterPeriod>("all");
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportPassword, setExportPassword] = useState("");
  const [exportLoading, setExportLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    fetchRecords();
  }, [user, filter]);

  const fetchRecords = async () => {
    setLoading(true);
    let query = supabase
      .from("screenings")
      .select("id,patient_name,patient_id,risk_level,ai_confidence,created_at,gender,age,location")
      .eq("user_id", user!.id)
      .order("created_at", { ascending: false });

    const now = new Date();
    if (filter === "today") {
      query = query.gte("created_at", new Date(now.setHours(0, 0, 0, 0)).toISOString());
    } else if (filter === "week") {
      query = query.gte("created_at", new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString());
    } else if (filter === "month") {
      query = query.gte("created_at", new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString());
    }

    const { data, error } = await query;
    if (!error && data) setRecords(data);
    setLoading(false);
  };

  const filtered = records.filter(
    (r) =>
      (r.patient_name || "").toLowerCase().includes(search.toLowerCase()) ||
      (r.patient_id || "").toLowerCase().includes(search.toLowerCase())
  );

  const handleExport = async () => {
    if (!exportPassword) { toast.error("Please enter your password"); return; }
    setExportLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: user!.email!, password: exportPassword });
      if (error) { toast.error("Incorrect password"); setExportLoading(false); return; }

      const { data: allRecords } = await supabase.from("screenings").select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      let exportData = allRecords || [];

      if (filter === "today") {
        const d = new Date(); d.setHours(0, 0, 0, 0);
        exportData = exportData.filter((r) => new Date(r.created_at || "") >= d);
      } else if (filter === "week") {
        exportData = exportData.filter((r) => new Date(r.created_at || "") >= new Date(Date.now() - 7 * 86400000));
      } else if (filter === "month") {
        exportData = exportData.filter((r) => new Date(r.created_at || "") >= new Date(Date.now() - 30 * 86400000));
      }

      const headers = ["ID", "Patient Name", "Patient ID", "Age", "Gender", "Phone", "Location", "Risk Level", "AI Confidence", "Plaque Index", "Gingival Index", "Overridden", "Referral Clinic", "Notes", "Screening Date"];
      const rows = exportData.map((r) => {
        // Use local date components to avoid timezone shifts
        let dateStr = "";
        if (r.created_at) {
          const d = new Date(r.created_at);
          const day = String(d.getDate()).padStart(2, "0");
          const month = String(d.getMonth() + 1).padStart(2, "0");
          const year = d.getFullYear();
          const hours = String(d.getHours()).padStart(2, "0");
          const minutes = String(d.getMinutes()).padStart(2, "0");
          dateStr = `${day}/${month}/${year} ${hours}:${minutes}`;
        }
        return [
          r.id, r.patient_name, r.patient_id, r.age, r.gender, r.phone, r.location,
          r.risk_level, r.ai_confidence, r.plaque_index, r.gingival_index,
          r.overridden, r.referral_clinic, (r.notes || "").replace(/,/g, ";"),
          dateStr,
        ].map((v) => `"${v ?? ""}"`)
      });

      const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `oralscan-records-${format(new Date(), "yyyy-MM-dd")}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("CSV exported successfully");
      setShowExportModal(false);
      setExportPassword("");
    } catch {
      toast.error("Export failed");
    } finally {
      setExportLoading(false);
    }
  };

  const filterLabels: Record<FilterPeriod, string> = { all: "All Time", today: "Today", week: "This Week", month: "This Month" };

  return (
    <MobileLayout className="pb-20">
      <ScreenHeader
        title="Screening Records"
        rightAction={
          <button onClick={() => setShowExportModal(true)} className="p-2 rounded-xl hover:bg-primary-foreground/10 transition-colors">
            <Download className="w-5 h-5 text-primary-foreground" />
          </button>
        }
      />

      <div className="px-4 pt-4 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by name or ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-12 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none"
          />
        </div>

        {/* Filter */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {(Object.keys(filterLabels) as FilterPeriod[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                filter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {filterLabels[f]}
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>{filtered.length} record{filtered.length !== 1 ? "s" : ""}</span>
          <span className="flex items-center gap-1"><Filter className="w-3.5 h-3.5" />{filterLabels[filter]}</span>
        </div>

        {/* Records */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <FileText className="w-12 h-12 text-muted-foreground/40" />
            <div>
              <p className="font-semibold text-foreground">No records found</p>
              <p className="text-sm text-muted-foreground mt-1">{search ? "Try a different search" : "Start a new screening to see records"}</p>
            </div>
            {!search && (
              <ActionButton onClick={() => navigate("/screening/consent")} fullWidth={false}>
                New Screening
              </ActionButton>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((record) => (
              <button
                key={record.id}
                onClick={() => navigate(`/records/${record.id}`)}
                className="w-full bg-card rounded-2xl border border-border p-4 text-left hover:border-primary/40 transition-all active:scale-[0.98]"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground truncate">{record.patient_name || "Unknown"}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{record.patient_id}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span className="capitalize">{record.age ? `${record.age}y` : ""} {record.gender || ""}</span>
                      {record.location && <span>· {record.location}</span>}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    {record.risk_level && <RiskBadge level={record.risk_level as "low" | "medium" | "high"} size="small" />}
                    <p className="text-xs text-muted-foreground">
                      {record.created_at ? format(new Date(record.created_at), "dd MMM") : ""}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={() => setShowExportModal(false)}>
          <div className="w-full max-w-md mx-auto bg-card rounded-t-3xl p-6 space-y-5" onClick={(e) => e.stopPropagation()}>
            <div className="w-10 h-1 bg-muted rounded-full mx-auto" />
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Lock className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-foreground text-lg">Export CSV</h3>
                <p className="text-sm text-muted-foreground">Confirm your password to export</p>
              </div>
            </div>
            <div className="bg-accent rounded-xl p-3 text-xs text-muted-foreground">
              Exporting: <span className="font-semibold text-foreground">{filterLabels[filter]}</span> data
            </div>
            <input
              type="password"
              placeholder="Enter your password"
              value={exportPassword}
              onChange={(e) => setExportPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleExport()}
              className="w-full h-14 px-4 rounded-xl border-2 border-border focus:border-primary bg-background text-foreground outline-none"
              autoFocus
            />
            <div className="grid grid-cols-2 gap-3">
              <ActionButton variant="outline" onClick={() => setShowExportModal(false)}>Cancel</ActionButton>
              <ActionButton onClick={handleExport} loading={exportLoading}>Export</ActionButton>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </MobileLayout>
  );
}
