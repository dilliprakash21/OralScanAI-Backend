import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ActionButton } from "@/components/ui/ActionButton";
import { Mail, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function OTPVerificationScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const email = (location.state as { email?: string })?.email || "";
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [verified, setVerified] = useState(false);

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value && index < 5) {
      const nextInput = document.querySelector(`input[name="otp-${index + 1}"]`) as HTMLInputElement;
      nextInput?.focus();
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = otp.join("");
    if (token.length !== 6) {
      toast.error("Please enter the complete 6-digit OTP");
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.verifyOtp({ email, token, type: "email" });
      if (error) {
        toast.error(error.message);
      } else {
        setVerified(true);
        setTimeout(() => navigate("/dashboard"), 1500);
      }
    } catch {
      toast.error("Verification failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (verified) {
    return (
      <MobileLayout className="items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-success" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">Verified!</h2>
          <p className="text-muted-foreground">Redirecting to dashboard...</p>
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout className="justify-center py-8">
      <div className="text-center mb-8 animate-fade-in">
        <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
          <Mail className="w-8 h-8 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">Verify Your Email</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          Enter the 6-digit code sent to<br />
          <span className="font-semibold text-foreground">{email}</span>
        </p>
      </div>

      <form onSubmit={handleVerify} className="space-y-6 animate-fade-in">
        <div className="flex gap-2 justify-center">
          {otp.map((digit, index) => (
            <input
              key={index}
              name={`otp-${index}`}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleOtpChange(index, e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Backspace" && !digit && index > 0) {
                  const prev = document.querySelector(`input[name="otp-${index - 1}"]`) as HTMLInputElement;
                  prev?.focus();
                }
              }}
              className="w-12 h-14 text-center text-xl font-bold border-2 border-border focus:border-primary rounded-xl bg-card text-foreground outline-none"
            />
          ))}
        </div>

        <ActionButton type="submit" loading={loading} disabled={otp.join("").length !== 6}>
          Verify OTP
        </ActionButton>
      </form>
    </MobileLayout>
  );
}
