import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ScreenHeader } from "@/components/layout/ScreenHeader";
import { ActionButton } from "@/components/ui/ActionButton";
import { Mail, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function ForgotPasswordScreen() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSendReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + "/login",
      });
      if (error) {
        toast.error(error.message);
      } else {
        setSent(true);
      }
    } catch {
      toast.error("Failed to send reset email.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <MobileLayout noPadding>
      <ScreenHeader title="Reset Password" />
      <div className="flex-1 px-4 py-6">
        {sent ? (
          <div className="text-center animate-fade-in">
            <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-success" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Email Sent!</h2>
            <p className="text-muted-foreground mb-8">
              Check your inbox at <span className="font-semibold text-foreground">{email}</span> for the password reset link.
            </p>
            <ActionButton onClick={() => navigate("/login")}>Back to Login</ActionButton>
          </div>
        ) : (
          <form onSubmit={handleSendReset} className="space-y-6 animate-fade-in">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Forgot Password?</h2>
              <p className="text-muted-foreground text-sm mt-2">Enter your email and we'll send a reset link</p>
            </div>

            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none"
                required
              />
            </div>

            <ActionButton type="submit" loading={loading} disabled={!email}>
              Send Reset Link
            </ActionButton>
            <ActionButton variant="outline" onClick={() => navigate("/login")}>
              Back to Login
            </ActionButton>
          </form>
        )}
      </div>
    </MobileLayout>
  );
}
