import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ActionButton } from "@/components/ui/ActionButton";
import { Eye, EyeOff, Mail, Lock, User, Stethoscope, Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import oralScanLogo from "@/assets/oralscan-logo.png";

const passwordRules = [
  { test: (p: string) => p.length >= 8, label: "At least 8 characters" },
  { test: (p: string) => /[A-Z]/.test(p), label: "At least 1 uppercase letter" },
  { test: (p: string) => /[0-9]/.test(p), label: "At least 1 number" },
  { test: (p: string) => (p.match(/[^A-Za-z0-9]/g) || []).length >= 2, label: "At least 2 special characters" },
];

function validateIndianPhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, "");
  if (digits.length === 0) return "Phone number is required";
  if (digits.length !== 10) return "Phone number must be exactly 10 digits";
  if (!/^[6-9]/.test(digits)) return "Enter a valid Indian mobile number";
  return null;
}

function validateEmail(email: string): string | null {
  if (!email) return "Please enter email";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Invalid email format";
  return null;
}

function validateName(name: string): string | null {
  if (!name.trim()) return "Name is required";
  if (!/^[A-Za-z\s.'-]+$/.test(name.trim())) return "Name must contain only letters";
  return null;
}

export default function SignupScreen() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState(localStorage.getItem("userRole") || "");
  const [licenseNo, setLicenseNo] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [agreed, setAgreed] = useState(false);

  const passwordValid = passwordRules.every((rule) => rule.test(password));

  const handleNameChange = (value: string) => {
    // Only allow letters, spaces, dots, apostrophes, hyphens
    const filtered = value.replace(/[^A-Za-z\s.'-]/g, "");
    setName(filtered);
  };

  const handlePhoneChange = (value: string) => {
    const digits = value.replace(/\D/g, "").slice(0, 10);
    setPhone(digits);
    if (digits.length > 0) {
      setPhoneError(validateIndianPhone(digits));
    } else {
      setPhoneError(null);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate all fields
    const nameErr = validateName(name);
    if (nameErr) { toast.error(nameErr); return; }

    const emailErr = validateEmail(email);
    if (emailErr) { toast.error(emailErr); return; }

    const phoneErr = validateIndianPhone(phone);
    if (phoneErr) { setPhoneError(phoneErr); toast.error(phoneErr); return; }

    if (!role) { toast.error("Please select a role"); return; }

    if (!passwordValid) { toast.error("Password does not meet requirements"); return; }

    if (password !== confirmPassword) { toast.error("Passwords do not match"); return; }

    if (!agreed) { toast.error("Please agree to the terms"); return; }

    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name.trim(),
            phone: `+91${phone}`,
            role,
            license_no: role === "dentist" ? licenseNo : undefined,
          },
          emailRedirectTo: window.location.origin + "/dashboard",
        },
      });

      if (error) {
        if (error.message.includes("already registered")) {
          toast.error("Email already exists. Please sign in instead.");
        } else {
          toast.error(error.message);
        }
        return;
      }

      if (data.user) {
        await supabase.from("profiles").upsert({
          user_id: data.user.id,
          name: name.trim(),
          email,
          phone: `+91${phone}`,
          role,
          license_no: role === "dentist" ? licenseNo : undefined,
        }, { onConflict: "user_id" });
      }

      toast.success("Registration successful! Please check your email to verify your account.");
      navigate("/login");
    } catch {
      toast.error("Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const isValid = name.trim() && !validateName(name) && email && !validateEmail(email) && phone && !phoneError && password && confirmPassword && role && agreed && password === confirmPassword && passwordValid;

  return (
    <MobileLayout className="py-6">
      <div className="text-center mb-6 animate-fade-in">
        <div className="w-14 h-14 bg-primary-foreground rounded-xl flex items-center justify-center mx-auto shadow-lg overflow-hidden">
          <img src={oralScanLogo} alt="OralScan AI" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-xl font-bold text-foreground mt-3">Create Account</h1>
      </div>

      <form onSubmit={handleSignup} className="space-y-3 animate-fade-in">
        {/* Role Selection */}
        <div className="space-y-1">
          <label className="text-sm font-semibold text-foreground">Select Role *</label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: "dentist", label: "Dentist" },
              { id: "health-worker", label: "Health Worker" },
            ].map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setRole(r.id)}
                className={`h-12 rounded-xl border-2 text-sm font-semibold transition-all ${
                  role === r.id
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground hover:border-primary/50"
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Name */}
        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input type="text" placeholder="Full Name (letters only)" value={name} onChange={(e) => handleNameChange(e.target.value)}
            className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" required />
        </div>

        {/* Email */}
        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input type="email" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" required />
        </div>

        {/* Phone */}
        <div>
          <div className="relative flex">
            <div className="flex items-center justify-center px-3 h-14 bg-muted border-2 border-r-0 border-border rounded-l-xl text-sm font-semibold text-foreground">+91</div>
            <div className="relative flex-1">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input type="tel" inputMode="numeric" placeholder="10-digit mobile number" value={phone}
                onChange={(e) => handlePhoneChange(e.target.value)} maxLength={10}
                className={`w-full h-14 pl-10 pr-4 rounded-r-xl border-2 ${phoneError ? "border-destructive" : "border-border focus:border-primary"} bg-card text-foreground outline-none`} required />
            </div>
          </div>
          {phoneError && <p className="text-xs text-destructive mt-1 ml-1">{phoneError}</p>}
          {!phoneError && phone.length === 10 && <p className="text-xs text-success mt-1 ml-1">✓ Valid number: +91 {phone}</p>}
        </div>

        {/* License No - Only for Dentist */}
        {role === "dentist" && (
          <div className="relative">
            <Stethoscope className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input type="text" placeholder="License / Registration No." value={licenseNo} onChange={(e) => setLicenseNo(e.target.value)}
              className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" />
          </div>
        )}

        {/* Password */}
        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input type={showPassword ? "text" : "password"} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full h-14 pl-12 pr-12 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" required />
          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2">
            {showPassword ? <EyeOff className="w-5 h-5 text-muted-foreground" /> : <Eye className="w-5 h-5 text-muted-foreground" />}
          </button>
        </div>

        {password && (
          <div className="grid grid-cols-2 gap-1 px-1">
            {passwordRules.map((rule) => (
              <div key={rule.label} className={`text-xs flex items-center gap-1 ${rule.test(password) ? "text-success" : "text-muted-foreground"}`}>
                <span>{rule.test(password) ? "✓" : "○"}</span>
                <span>{rule.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Confirm Password */}
        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}
            className={`w-full h-14 pl-12 pr-4 rounded-xl border-2 ${confirmPassword && password !== confirmPassword ? "border-destructive" : "border-border focus:border-primary"} bg-card text-foreground outline-none`} required />
        </div>

        {/* Terms */}
        <label className="flex items-start gap-3 p-3 rounded-xl border border-border cursor-pointer">
          <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className="mt-0.5 w-4 h-4 accent-primary" />
          <span className="text-sm text-muted-foreground">I agree to the clinical disclaimer and terms of use for OralScan AI</span>
        </label>

        <ActionButton type="submit" loading={loading} disabled={!isValid}>
          Create Account
        </ActionButton>
      </form>

      <p className="text-center text-sm text-muted-foreground mt-4">
        Already have an account?{" "}
        <Link to="/login" className="text-primary font-semibold">Sign In</Link>
      </p>
    </MobileLayout>
  );
}
