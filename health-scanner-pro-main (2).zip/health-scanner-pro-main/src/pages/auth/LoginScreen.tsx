import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { ActionButton } from "@/components/ui/ActionButton";
import { Eye, EyeOff, Mail, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import oralScanLogo from "@/assets/oralscan-logo.png";

export default function LoginScreen() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) { toast.error("Please enter email"); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast.error("Invalid email format"); return; }
    if (!password) { toast.error("Please enter password"); return; }

    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        if (error.message.includes("Email not confirmed")) {
          toast.error("Account not verified. Please check your email.");
        } else {
          toast.error("Invalid credentials. Please check your email and password.");
        }
      } else {
        navigate("/dashboard");
      }
    } catch {
      toast.error("Login failed. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <MobileLayout className="justify-center py-8">
      <div className="text-center mb-10 animate-fade-in">
        <div className="w-16 h-16 bg-primary-foreground rounded-2xl flex items-center justify-center mx-auto shadow-lg overflow-hidden">
          <img src={oralScanLogo} alt="OralScan AI" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mt-4">Welcome Back</h1>
        <p className="text-muted-foreground mt-1">Sign in to continue screening</p>
      </div>

      <form onSubmit={handleLogin} className="space-y-4 animate-fade-in">
        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input type="email" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full h-14 pl-12 pr-4 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" required />
        </div>

        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input type={showPassword ? "text" : "password"} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full h-14 pl-12 pr-12 rounded-xl border-2 border-border focus:border-primary bg-card text-foreground outline-none" required />
          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2">
            {showPassword ? <EyeOff className="w-5 h-5 text-muted-foreground" /> : <Eye className="w-5 h-5 text-muted-foreground" />}
          </button>
        </div>

        <div className="text-right">
          <Link to="/forgot-password" className="text-sm text-primary font-medium">Forgot Password?</Link>
        </div>

        <ActionButton type="submit" loading={loading} disabled={!email || !password}>
          Sign In
        </ActionButton>
      </form>

      <p className="text-center text-sm text-muted-foreground mt-6">
        Don't have an account?{" "}
        <Link to="/role-select" className="text-primary font-semibold">Sign Up</Link>
      </p>
    </MobileLayout>
  );
}
